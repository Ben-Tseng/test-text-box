# Blurb Autobot

这是一个基于你提供的 bookmarklet 改写的 Firefox 扩展。

## 功能

- 管理模板：新建、编辑、删除
- 使用 `browser.storage.local` 持久化模板
- 一键将模板内容填充到当前页面
- 自动设置主题、正文、分类、原因，并触发提交按钮

## 安装

1. 打开 Firefox。
2. 访问 `about:debugging#/runtime/this-firefox`。
3. 点击“临时载入附加组件”。
4. 选择这个目录里的 `manifest.json`。

## 文件

- `manifest.json`：Firefox 扩展配置
- `popup.html` / `popup.css` / `popup.js`：弹窗界面与逻辑

## 说明

- 默认会导入你原脚本中的“模板1”。
- 点击“应用”时，会把模板填入当前活动标签页。
- 如果目标页面 DOM 结构变化，比如 `katal-id-*` 或下拉框位置变了，需要同步更新 `popup.js` 里的注入逻辑。
